 import java.io.*;
public class fifo 
{
    public static void main(String[] args) throws Exception
    {
        int numFrame;
		int numPage;
		int num=0;
		int pageHit=0;
        int pages[];
        int frame[];
        boolean flag = true;
       
        BufferedReader buffer= new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter number of frames : ");
        numFrame = Integer.parseInt(buffer.readLine());
        System.out.println("Enter number of pages : ");
        numPage = Integer.parseInt(buffer.readLine());
       
        frame = new int[numFrame];
        pages = new int[numPage];
       
        for(int i=0; i<numFrame; i++)
        {
            frame[i] = -1;
        }
       
        System.out.println("Enter page number : ");
        for(int i=0;i<numPage;i++)
            pages[i] = Integer.parseInt(buffer.readLine());
       
        for(int i=0; i<numPage; i++)
        {
            flag = true;
            int page = pages[i];
            for(int j=0; j<numFrame; j++)
            {
                if(frame[j] == page)
                {
                    flag = false;
                    pageHit++;
                    break;
                }
            }
            if(num == numFrame)
                num = 0;
           
            if(flag)
            {
                frame[num] = page;
                num++;
            }
            System.out.print("frame : ");
            for(int k=0; k<numFrame; k++)
                System.out.print(frame[k]+" ");
            System.out.println();
           
        }
        System.out.println("No. of page hit : "+pageHit);
    }
}